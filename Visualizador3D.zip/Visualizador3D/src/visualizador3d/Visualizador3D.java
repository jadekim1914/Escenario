/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package visualizador3d;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import com.jogamp.opengl.*;
import com.jogamp.opengl.util.FPSAnimator;
import visualizador3d.ObjReader;
import visualizador3d.Object3d;
import visualizador3d.MyCanvas;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

/**
 *
 * @author gmendez
 */
public class Visualizador3D {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Visualizador3D ol = new Visualizador3D();
        ol.test("./data/Wood Texture.obj");

    }

    public void test(String fileName) {
                  
            // o.printVectors();

            JFrame fr = new JFrame();
            MyCanvas canvas = new MyCanvas(fileName);
            
            final FPSAnimator animator = new FPSAnimator(canvas, MyCanvas.FPS, true);
            
            fr.getContentPane().add(canvas);
            
            fr.addKeyListener(canvas);
            
            fr.addWindowListener(new WindowAdapter() {
               @Override
               public void windowClosing(WindowEvent e) {
                  // Use a dedicate thread to run the stop() to ensure that the
                  // animator stops before program exits.
                  new Thread() {
                     @Override
                     public void run() {
                        if (animator.isStarted()) animator.stop();
                        System.exit(0);
                     }
                  }.start();
               }
            });
                        
            fr.setTitle("Testing object view");
            fr.pack();
            fr.setVisible(true);
            animator.start(); // start the animation loop

    }

}
